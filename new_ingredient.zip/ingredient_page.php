<?php
$loginPage = TRUE;
include "page_init.php";
?>
		<!--<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>       
						<span class="icon-bar"></span>      
						<span class="icon-bar"></span>                      
					</button>
					<a class="navbar-brand" href="./index.php">General Store</a>
				</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
      		<li><a href="./index.php">Home</a></li>
      		<li><a href="./ingredientslist.php">Ingredients</a></li>
      		<li><a href="./about_us.php">About Us</a></li>
    			</ul>
			<form class="navbar-form navbar-right">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>	 
			
			</div>
			</div>
		</nav>-->
		
		<div class="col-md-2 col-lg-2">
		<ul class="list-group">
  <li class="list-group-item">
        			<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ingredients
        			<span class="caret"></span></a>
       			 <ul class="dropdown-menu">
          			<?php $bloop = database::getIngredients($dbh);?>
        			<?php foreach($bloop as $d){ ?>
        			<?php echo "<li><a href=./ingredient_page?q=$d->id>$d->name</a></li>";?>
					<?php } ?> 
        			</ul>
     		 </li>
  <li class="list-group-item">
        			<a class="dropdown-toggle" data-toggle="dropdown" href="#">Recipes
        			<span class="caret"></span></a>
        			<ul class="dropdown-menu">        		 
         		 <li><a href="#">Appetizers</a></li>
          			<li><a href="#">Mains</a></li>
          			<li><a href="#">Desserts</a></li>
        			</ul>
      		</li>
</ul>				</div>
		<div class="col-md-4 col-lg-4"> 
		<?php
		$site= $_GET['url']."ajax_ingredient.php";
		$ing = $_GET['ingred'];
		$url = $site."?ing=".$ing;
		$imageUrl = $_GET['url']."ajax_ingrimage.php?ing=".$ing;
		$json=file_get_contents($url, true);
		$json_dec=json_decode($json, true);
		$img = file_get_contents($imageUrl);
		echo"<h2>$ing</h2>";
				echo"<p>Price: ".$json_dec['cost']. " per ".$json_dec['unit']."</p>";
				echo "<img src=".$img.".></img>";
				echo"<p>image source: <cite>morguefile</cite></p>";		
		static $cartItems = array();
		static $numItems = array();
		if(isset($_SESSION['un']) && $_SESSION['lo']=='yes') {
		echo '<form action ="#" method="post">
			<input type="submit" name="cart" value="Add To Cart" style = "color: black;">
		</form>';
		}
		
		if(isset($_POST['cart'])) {
			/*$name = str_replace(' ', '', $i->name);
			if(! isset($_SESSION['cart'][$name])) {
				$name = str_replace(' ', '', $i->name);
				$cartItems[$name] = $i->price;
				$numItems[$name]=1;
				$_SESSION[$name] = 1;
			} else {
				$name = str_replace(' ', '', $i->name);
				$_SESSION[$name] += 1;
				$price = ($i->price) * $_SESSION[$i->name];
				$cartItems[$name] = $price;
				$numItems[$name] +=1;
			}
			
			
			//$_SESSION['numItems'] += 1;
			$_SESSION['cartItems'] = $cartItems;
			
			if(isset($_SESSION['cartItems'])) {
				if(isset($_SESSION['cart'])) {
					$_SESSION['cart'] += $_SESSION['cartItems'];
				} else {
					$_SESSION['cart'] = $_SESSION['cartItems'];
				}
				foreach($_SESSION['cart'] as $key=>$value) {
					foreach($_SESSION['cartItems'] as $key1=>$value1) {
						if($key1 == $key) {
							$newVal = $_SESSION['cartItems'][$key1];
							$_SESSION['cart'][$key] = $newVal;
						}
					}
					
				}
			}*/
			if(isset($_SESSION['cartItems'])) {
			$cartItems=$_SESSION['cartItems'];}
			$sc='no';
			foreach ($cartItems as $c=>$e){
			if ($c==$i->id.$i->name){
			$cartItems[$c]=$e+1;
			$sc='yes';
			}}
			if($sc=='no') {
				$cartItems[$i->id.$i->name]=1;
				}
			$_SESSION['cartItems']=$cartItems;
			echo 'Item added to cart!';
		}
				?> 
					</div>
		<div class="col-md-6 col-lg-6">
		<h2>Description</h2>
		<?php 
		$site= $_GET['url']."ajax_ingredient.php";
		$ing = $_GET['ingred'];
		$url = $site."?ing=".$ing;
		$json=file_get_contents($url, true);
		$json_dec=json_decode($json, true);
		echo $json_dec['desc'];
		?>
		<p>Source: <cite>Wikipedia</cite></p>
		</div>	
		<?php if(($_SESSION['lo']=="yes")) :?>
		<div class="container-comment">
			<h2>Comments for Ingredient</h2>
			<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#com">Comment:</a></li>
  <li><a data-toggle="tab" href="#prevcom">View Previous: </a></li>
</ul>
<div class="tab-content">
  <div id="com" class="tab-pane fade in active">
    <?php if(!($_SESSION['lo']=="yes")) :?>
			<p> Only authorized users are allowed to comment. Please log-in.</p>
			<?php else :?>
			<form method="POST">
				<div class="form-group-comment">
					<label for="comment">Comment:</label>
					<textarea class="form-control" rows="5" id="comment" name="comment" style="color: black;"></textarea>
					<button type="submit" class="btn btn-default" style="float: none;">Submit</button>
				</div>
			</form>
			<?php endif; ?>
  </div>
  <div id="prevcom" class="tab-pane fade">
	<?php if(!($_SESSION['lo']=="yes")) :?>
			<p> Log in to view previous comments.</p>
	<?php else	:?>	    
    <?php
			if(isset($_POST['comment'])) {
				$c = array();
				$c['comment']=filter_var($_POST['comment'], FILTER_SANITIZE_STRING);
				$c['id']=$_GET['q'];
				$c['com_id']=database::getNumberOfComments($dbh)+1;
			testedInsertComment($c, $dbh);}		
			?>
	<?php endif; ?>		
			<?php if($_SESSION['lo']=="yes") : ?>
					<h4>Previous Comments:</h4>
					<div class="panel panel-default" style="color: black;">
					<div class="panel-body"><?php $zip = database::getComments($_GET['q'], $dbh);?>
		<?php foreach($zip as $j){
		echo "<p>$j->comment</p>";}
		if($zip==null){
		echo "There are no comments to view.";} ?></div></div>						 
	<?php endif; ?>			
  </div>
  </div>
<?php endif; ?>
		</div>
	</body>
	<div id="footer">
		<?php include "footer.php"; ?>
	</div>
</html>