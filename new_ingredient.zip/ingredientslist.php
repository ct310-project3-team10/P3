<?php 
$loginPage = TRUE;
include "page_init.php";?>
<script type="text/javascript" src="ingredientslist.js">
</script>
		<!--<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>       
						<span class="icon-bar"></span>      
						<span class="icon-bar"></span>                      
					</button>
					<a class="navbar-brand" href="index.php">General Store</a>
				</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
      		<li><a href="index.php">Home</a></li>
      		<li class="active"><a href="./ingredients.php">Ingredients</a></li>
      		<li><a href="./about_us.php">About Us</a></li>
    			</ul>
			<form class="navbar-form navbar-right">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>	 
			
			</div>
			</div>
		</nav>-->
		
		
		
		
		
		<div class="container-fluid">
			<div class="row visible-on">
				<table id="feds2">
				<th style="text-decoration:underline;width=50%"> Supplier </th>
				<th style="text-decoration:underline;">Available Ingredients </th>
					<?php
					error_reporting(0); //This is due to some sites not having status formatted correctly causing a 404 error
					$json = file_get_contents("https://www.cs.colostate.edu/~ct310/yr2017sp/more_assignments/project03masterlist.php", true);
					$json_dec = json_decode($json, true);
					foreach($json_dec as $name=>$val){
							$status = file_get_contents($val["baseURL"]."ajax_status.php", true);
							$stat_dec=json_decode($status, true);
							if($stat_dec["status"] == "open"){
								$url=$val["baseURL"];
							echo "<tr>";
							echo "<td width=25%><a href=".$val["baseURL"].">".$val["nameLong"]."</a></td>";
							$ing_list= file_get_contents($val["baseURL"]."/ajax_listing.php", true);
							$ing_dec=json_decode($ing_list, true);
							echo "<div id=ing>";
							foreach($ing_dec as $name=>$val){
								$link = "ingredient_page.php?url=".$url."&ingred=".$val['name'];
								echo "<td><a href=".$link.">".$val["name"]."</a></td>";
							}
							 echo "</tr>";
							 echo "</div>";
						}
					}
					?>
				
					</th>
				</table>
			</div>
		</div>
		
	</body>
	<div id="footer">
		<?php include "footer.php"; ?>
	</div>
</html>