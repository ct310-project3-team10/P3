<?php
require_once("comment.php");
class ingredient{
	public $name;
	public $description;
	public $photo;
	public $id;
	public $price;
	function __construct($name="",$description="",$photo="",$id=0,$price=0) {
	$this->name = $name;
	$this->description = $description;
	$this->photo = $photo;
	$this->id = $id;
	$this->price = $price;
	}
	public static function getIngredientFromRow($row){
		$i = new ingredient();
		$i->name= $row['name'];
		$i->description = $row['description'];
		$i->photo = $row['photo'];
		$i->id = $row['id'];
		$i->price = $row['price'];
		return $i;
	}
	public static function getLI($row){
		$i = new ingredient();
		$i->name= $row['name'];
		$i->id = $row['id'];
		return $i;
	}
	function __toString() {
	return (string)$this->name;
	}
}