<?php 
include "header.php";
include "database.php";
include "db_init.php";
$dbh=setupConnectionI();
//$dbh2=setupConnectionU();
//dropTableByName("ingredient");
//dropTableByName("Comments");
//createTableIngredient($dbh);
//createTableComments($dbh);
//loadEmptyDatabase($dbh);
if(isset($_GET['q'])) {
$i = database::getDetails($_GET['q'],$dbh);}
?>
