
	<div class="footer" style="text-align: center; padding: 5px; clear: both;">
			<p> </p>
			<p> </p>
			<p> </p>
			<h3><a href="./index.php">Home</a>
      		<a href="http://www.colostate.edu">CSU</a>
      		<a href="http://www.cs.colostate.edu">CS</a></h3>
		<p>© Copyright 2017, Freshest Produce Supply</p>
		<p>Disclaimer: This is not a real company. This site is part of a CSU <a href="https://www.cs.colostate.edu/~ct310/yr2017sp/index.php">CT 310</a> Course Project.</div>
</html>