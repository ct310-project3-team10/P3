<?php 
$loginPage = TRUE;
include "page_init.php";?>
	
		<!--<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>       
						<span class="icon-bar"></span>      
						<span class="icon-bar"></span>                      
					</button>
					<a class="navbar-brand" href="./index.php">General Store</a>
				</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
      		<li><a href="./index.php">Home</a></li>
      		<li><a href="./ingredientslist.php">Ingredients</a></li>
      		<li class="active"><a href="./about_us.php">About Us</a></li>
    			</ul>
			<form class="navbar-form navbar-right">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>	 
			
			</div>
			</div>
		</nav>-->
		
		<div class="container-fluid">
			<div class="row visible-on">
				<div class="col-md-2 col-lg-2">
				<ul class="list-group">
  <li class="list-group-item">
        			<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ingredients
        			<span class="caret"></span></a>
       			 <ul class="dropdown-menu">
          			<?php $bloop = database::getIngredients($dbh);?>
        			<?php foreach($bloop as $d){ ?>
        			<?php echo "<li><a href=./ingredient_page?q=$d->id>$d->name</a></li>";?>
					<?php } ?> 
        			</ul>
     		 </li>
  <li class="list-group-item">
        			<a class="dropdown-toggle" data-toggle="dropdown" href="#">Recipes
        			<span class="caret"></span></a>
        			<ul class="dropdown-menu">
         		 <li><a href="#">Appetizers</a></li>
          			<li><a href="#">Mains</a></li>
          			<li><a href="#">Desserts</a></li>
        			</ul>
      		</li>
</ul>				
		</div>
				<div class="col-md-7 col-lg-7">
				<h2>About Us:</h2>				
				<p>
				The Freshest Produce Supply was started in 2001 when our founder Fred P. Storensk saw the lack of access to
				truely farm to table ingredients in urban areas. Back then, he personally drove across the United 
				States and Canada meeting farmers. He was driven by passion and a desire to beat his brother
				Gene at his own game. He slowly but surely laid the network of farmers that ship for 
				General Store today. Curently, the Freshest Produce Supply has a network of 1301 farmers across 4 continents!
				They ship their crops directly to you without a middle man. For this reason our selection of ingredients
				is constantly varying based on what is in season and what is available. Check back often to see what
				we have for you.
				</p>
				<h5>Thank you for choosing the Freshest Produce Supply!</h5>
				<h3>Contact Us:</h3>
				<li>Phone: 970-FPS-STOR</li>
				<li>Email: freakyfreshproduce@fakeemail.net</li>
				</div>
				<div class="col-md-3 col-lg-3 hidden-sm hidden-xs">
					<img src="./pictures/index.jpg" class="img-circle" alt="old truck" width="200" height="200">
					<p>image source: <cite>morguefile</cite></p> 
					
			</div>
			
			</div>
		</div>
		
	</body>
	<div id="footer">
		<?php include "footer.php"; ?>
	</div>
</html>