<?php
if(isset($_SESSION['un']) && $_SESSION['un'] != "Guest") {
	$loginPage = TRUE;
} else {
	$loginPage = FALSE;
}
include "page_init.php";
?>
	
		
<?php

if(isset($_POST['name']) && isset($_POST['description']) && isset($_POST['price']) && isset($_FILES['image'])) {
	if($_FILES ['image'] ['type'] == 'image/jpeg') {
	$pagename = $_POST['name'];
	$my_file = './descriptions/'.$pagename.".txt";
	$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
	$data = $_POST['description'];
	fwrite($handle, $data);
	fclose($handle);
	
	$imgName = "./pictures/" . $_FILES['image']['name'];
	$idNum = Database::getNumberOfIngredients($dbh) + 1;
	move_uploaded_file($_FILES['image']['tmp_name'], $imgName);
	chmod($imgName, 0755);
	$inArray = array( "name" => $_POST['name'], 
						"description" => $_POST['description'], 
						"photo" => $imgName, 
						"id" => $idNum,
						"price" => $_POST['price']);
	
	InsertIngredient($inArray, $dbh);
	
	$a = database::getIngredients($dbh);
	//print_r($a);
	echo '<br>';
	echo $imgName;
	echo $_FILES['image'];
	echo 'Upload successful';
}
	else {
	echo 'Must upload jpeg image!';}} 
	else {
	$a = database::getIngredients($dbh);
	//print_r($a);
	echo '<br><form action="#" method="post" enctype="multipart/form-data">
	Ingredient Name:<br>
	<input type="text" name="name" style="color:black;"><br>
	Description:<br>
	<textarea name="description" style="color:black;"></textarea><br>
	Price:<br>
	<input type="text" name="price" style="color:black;"><br>
	Image (.jpg only):<br>
	<input type="file" name="image" id="image" style="color:black;">
	<input type="submit" value="Submit" style="color:black;">
</form>';
}
?>
<?php if(isset($_POST['tb'])) {
	if($_POST['tb']=='ingredient') {
	dropTableByName('ingredient');
	dropTableByName('Comments');
	unset($_POST['tb']);
	createTableIngredient($dbh);
	createTableComments($dbh);
	echo "ingredient and comment table dropped from database.";	
	//loadEmptyDatabase($dbh);
	}
	elseif($_POST['tb']=='comment'){
		dropTableByName('Comments');
	unset($_POST['tb']);
	createTableComments($dbh);}
	echo "comment table dropped from database.";}
		?>
<div class="container-fluid" style="background-color: black; text-align: center;">	
<p>Type "ingredient" or "comment" in the form below to clear table.</p>
<form action="#" method="POST">
  				<div class="form-group" style="width: 300px; margin: 0 auto; color: white;">
    			<label for="username">DropTable:</label>
    			<input type="username" class="form-control" id="tb" name="tb">
    			<button type="submit" class="btn btn-default"style="float: none;">Submit</button>
    			</form>
    			</div></div>
	
	
	
	
	
<?php
include "footer.php";
?>
