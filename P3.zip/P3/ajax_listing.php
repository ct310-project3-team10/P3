<?php
include "database.php";
include "db_init.php";
$dbh=setupConnectionI();
header ( 'Content-Type: text/json' );
header ( "Access-Control-Allow-Origin: *" );
$a = array ();
$i = 0;
$bloop = database::getIngredients($dbh);
       foreach($bloop as $d){
       	$z=database::getDetails($d->id, $dbh);
			$a [$i++] = array('name' => $z->name, 'short' => 'fresh'.$z->name, 'unit' => 'lb', 'cost' => $z->price);}

echo json_encode ( $a );

?>