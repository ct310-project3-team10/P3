<?php
class comment{
	public $id;
	public $comment;
	public $com_id;
	function __construct($comment="", $id=0, $com_id=0) {
		$this->id = $id;
		$this->comment = $comment;
		$this->com_id = $com_id;
	}
	public static function getLI($row){
		$i = new comment();
		$i->comment= $row['comment'];
		$i->id= $row['id'];
		return $i;
	}
}