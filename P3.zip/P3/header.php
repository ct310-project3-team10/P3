<?php 
$ses_name = "log_on";
session_name($ses_name);
session_start();
$host = $_SERVER ['HTTP_HOST'];
$uri = rtrim ( dirname ( $_SERVER ['PHP_SELF'] ), '/\\' );
if (! isset ( $_SESSION ['un'] )) {
	$_SESSION ['un'] = "Guest";
}
if ( isset ( $_SESSION ['key'] )) {
	$loginPage = TRUE;
}
if (!$loginPage && ($_SESSION ['un'] == "Guest")) {
 	header ( "Location: https://$host$uri/login.php" );
	exit ();
}
if(!(isset ($_SESSION['lo']))) {
	$_SESSION['lo']="no";
	$_SESSION['lot']=null;}
include "support.php";
$users = readUsers();
$userStatus = "";
if(isset($_SESSION['un'])) {
foreach( $users as $u ) {
        if($u->user_name == $_SESSION['un']) {
            $userStatus = $u->status;
        }
    }
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">	
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="custom.css"/>
		<title>Freshest Produce Supply</title>
		<meta name = "description" content = "Freshest Produce Supply is your source for all the freshest farm to table ingredients!"/>
		<meta name="keywords" content="Freshest, Produce, Supply" />
		<meta name="authors" content=" Micah Wells Nate Barteaux" />
	</head>
	<style type="text/css">
   body { background: black; !important; color: white;}
</style>

	<body>

		<div class="jumbotron">
            <?php 
            if($_SESSION['lo']=="no"){
				echo '<form action="login.php">
				<button>Log In?</button>
				</form>';
				}
            else if($_SESSION['lo'] == "yes") {
				echo '<form action="log_out.php">
				<button>Log Out?</button>
				</form><br><br>';

				if($userStatus == "admin") {
				 echo '<form action="createIngredient.php">
				<button>Admin Portal</button>
				</form><br>';
				}
				
				}
        ?>
		<h1><style="text-align:center;" />Freshest Produce Supply</h1>
		<p><cite>Image taken from MorgueFile free photo archive by Kconnors</p>
		</div>
		
		
			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>       
							<span class="icon-bar"></span>      
							<span class="icon-bar"></span>                      
						</button>
						<a class="navbar-brand" href="./index.php">General Store</a>
					</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav">
	      		<li><a href="./index.php">Home</a></li>
	      		<li><a href="./ingredientslist.php">Ingredients</a></li>
	      		<li><a href="./about_us.php">About Us</a></li>
	      		<li><a href="./fedr_status.php">Partners</a></li>
					<?php if($_SESSION['un'] != "Guest") {
					 echo '<li><a href="./cart.php"> <button type="button" class="btn btn-default btn-sm">
					       <span class="glyphicon glyphicon-shopping-cart"></span> Shopping Cart
					   </button> </a></li>';
				} ?>
	    			</ul>
				<form class="navbar-form navbar-right">
	      <div class="form-group">
	        <input type="text" class="form-control" placeholder="Search">
	      </div>
	      <button type="submit" class="btn btn-default">Submit</button>
	    </form>	 
			
				</div>
				</div>
			</nav>
		
		
