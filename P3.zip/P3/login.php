<?php 
$loginPage = TRUE;
include "page_init.php";?>

		<!--<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>       
						<span class="icon-bar"></span>      
						<span class="icon-bar"></span>                      
					</button>
					<a class="navbar-brand" href="./index.php">General Store</a>
				</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
      		<li><a href="./index.php">Home</a></li>
      		<li><a href="./ingredientslist.php">Ingredients</a></li>
      		<li><a href="./about_us.php">About Us</a></li>
    			</ul>
			<form class="navbar-form navbar-right">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>	 
			
			</div>
			</div>
		</nav>-->
		
		<div class="container-fluid" style="background-color: black; text-align: center;">
			<div class="row visible-on">
			<?php date_default_timezone_set('MST'); ?>
			<?php
			if(isset($_POST['un'])) :?> 
			<?php if(password_verify($_POST['entered'], userHashByName($users, $_POST['un']))) :?>{
				<?php 
				$_SESSION['un']=$_POST['un'];
				$_SESSION['lo']= "yes";
				$_SESSION['lot']=date('m/d/y \a\t h:i:s A');
				header("Location: https://www.cs.colostate.edu/~mlwells/P2/index.php");?>
			<?php else :?>
			<h4>Login Unsuccesful</h4>
			<a href="./login.php">try again?</a>
			<?php endif;?>
			<?php else :?>	
				<form action="#" method="POST">
  				<div class="form-group" style="width: 300px; margin: 0 auto; color: white;">
    			<label for="username">Username:</label>
    			<input type="username" class="form-control" id="username" name="un">
  				</div>
  				<div class="form-group"style="width: 300px; margin: 0 auto; color: white;">
    			<label for="pwd">Password:</label>
    			<input type="password" class="form-control" id="pwd" name="entered">
  				</div>
  				<button type="submit" class="btn btn-default"style="float: none;">Submit</button>
				</form>
				</div>
				<h4>Forgot your password? <a href="./FMP.php" >click here</a></h4>
				</div></div>
			<?php endif;?>
		</body>		
	<div id="footer">
		<?php include "footer.php"; ?>
	</div>
</html>