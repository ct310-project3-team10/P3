<?php 
$loginPage = TRUE;
include "page_init.php";?>
<script type="text/javascript" src="ingredientslist.js">
</script>
		<!--<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>       
						<span class="icon-bar"></span>      
						<span class="icon-bar"></span>                      
					</button>
					<a class="navbar-brand" href="index.php">General Store</a>
				</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
      		<li><a href="index.php">Home</a></li>
      		<li class="active"><a href="./ingredients.php">Ingredients</a></li>
      		<li><a href="./about_us.php">About Us</a></li>
    			</ul>
			<form class="navbar-form navbar-right">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>	 
			
			</div>
			</div>
		</nav>-->
		
		<div class="container-fluid">
			<div class="row visible-on">
				<table id="feds2">
			<tr>
				<th>Supplier  </th>
				<th>Ingredient</th>
			</tr>
		</table>
			</div>
		</div>
		
	</body>
	<div id="footer">
		<?php include "footer.php"; ?>
	</div>
</html>