<?php 
if(isset($_SESSION['un']) && $_SESSION['un'] != "Guest") {
	$loginPage = TRUE;
} else {
	$loginPage = FALSE;
}
include "page_init.php" ?>
		
		<div class="container-fluid">
			<div class="row visible-on">
				<!--<div class="col-md-2 col-lg-2" style="cl">
				<ul class="list-group">
  <li class="list-group-item">
        			<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ingredients
        			<span class="caret"></span></a>
       			 <ul class="dropdown-menu">
          			
        			</ul>
     		 </li>
  <li class="list-group-item">
        			<a class="dropdown-toggle" data-toggle="dropdown" href="#">Recipes
        			<span class="caret"></span></a>
        			<ul class="dropdown-menu">
         		 <li><a href="#">Appetizers</a></li>
          			<li><a href="#">Mains</a></li>
          			<li><a href="#">Desserts</a></li>
        			</ul>
      		</li>
</ul>				
		</div>-->
		
		
		<h1>Your Shopping Cart:</h1><br>
		
		<?php
		if(isset($_SESSION['cartItems'])) {
			$cartItems=$_SESSION['cartItems'];
	if(isset($_POST['red'])) {
		foreach ($cartItems as $c=>$e){
			if($e==0) {
				unset($cartItems[$c]);
				//$_SESSION['cartItems']=$cartItems;
				//header("Location: http://www.cs.colostate.edu/~mlwells/P2/cart.php");
				}
			else {
			$z=database::getDetails(substr($c,0,1),$dbh);
			if ($z->name==(substr($_POST['red'],7,strlen($_POST['red'])))){			
			$cartItems[$c]=$e-1;
			}}
			}
			unset($_POST['red']);
			$_SESSION['cartItems']=$cartItems;			
			}} 
		$total = 0;
		$i = 0;
		$rm = array();
		if(isset($_SESSION['cartItems'])&&$_SESSION['cartItems']!=null) {
			foreach($_SESSION['cartItems'] as $key2=>$value2) {
				if($value2!=0) {
				$z=database::getDetails(substr($key2,0,1),$dbh);
				echo "<img src=$z->photo class=img-rounded alt=$z->name width= 75px height=75px>";
				echo '<h4>Item: '.$z->name.'&nbsp &nbsp &nbsp Quantity:'.$value2.'&nbsp &nbsp &nbsp Price: $'.$z->price*$value2.'</h4>
					<form action="#" method="post"style=color:black;>
				<input type="submit" value="Remove '.$z->name.'" name=red id='.$key2.'style=color:black;>
				</form><br>';
				$rm[$key2] = $i;
				$i++;
				$total += $z->price*$value2;
			}}
		if($i!=0) {		
		echo '<br><h4>Total: $'.$total.'<br>';
		echo '<form action="#" method="post">
				<input type="submit" value="Submit Order" name="checkout"style=color:black;>
				</form><br>';
	
	}} if($i==0) {
		echo '<h4>Your shopping cart is empty. Go to <a href=./ingredientslist.php>Ingredients Page.</a><h4>';
		echo '<h4>Total: $'.$total.'<br>';
	}
	
	/*if(isset($_SESSION['cart'])) {
	foreach($_SESSION['cart'] as $key2=>$value2) {
		if(isset($_POST[$key2])) {
			$_SESSION['cart'][$key2] = 0;
			if(sizeof($_SESSION['cart']) == 1) {
				$_SESSION['cart'] = Array();
			} else {
				unset($_SESSION['cart'][$key2]);
			}
		}
	}
}*/

$msg = '';
$success = '';
	if(isset($_POST['checkout'])&&isset($_SESSION['cartItems'])&&$_SESSION['cartItems']!=null) {
		include_once "support.php";
		$users = readUsers();
		
		$subj = 'Order Confirmation';
		$msg = 'Thank you for shopping at The Freshest Produce Supply! Your order has been submitted.
			
			';
		foreach($_SESSION['cartItems'] as $key=>$value) {
			$z=database::getDetails(substr($key2,0,1),$dbh);
			$msg = $msg. 'Item: '.$z->name.' Quantity: '.$value.' Price: $'.$z->price*$value.'
				
				';
		}
		$msg = $msg. 'Total: $'.$total.'<br>';
		
		foreach($users as $u) {
			if(($u->status == 'admin') || ($u->user_name == $_SESSION['un'])) {
				if(mail($u->email, $subj, strip_tags($msg))) {
					$success = 'Order submitted. E-mail confirmation sent.';
				} else {
					echo 'Error submitting order. Please make sure valid e-mail address is being used.';
				}
			}
		}
		if(mail("cdmi2@comcast.net", $subj, strip_tags($msg))) {
			$_SESSION['cart'] = Array();
			echo 'Order submitted. E-mail confirmation sent.';
			unset($_SESSION['cartItems']);
		} else {
			echo 'Error submitting order. Please make sure valid e-mail address is being used.';
		}
		
		header("Location: http://www.cs.colostate.edu/~mlwells/P2/cart.php");
	}
		?>
		
		
		
		
<?php include "footer.php"  ?>