jQuery(document).ready(function() {
	alert("im working");
var vurl = 'http://www.cs.colostate.edu/~ct310/yr2017sp/more_assignments/project03masterlist.php';

	jQuery.post(vurl, {}, function (data) {
		//var rt = "";
	//var tab = document.getElementById('feds');
	//var i = tab.rows.length;
	var len = data.length;
	for (j = len - 1; j >= 0; j--) {
		/*rt  = "<tr><td>";
		rt += data[j].nameShort+"</td>";
		rt += "<td id = "+data[j].nameShort+">" + data[j].nameLong + "</td> </tr>";
		var rr = tab.insertRow(i);
		rr.innerHTML = rt;
		isOpen(data[j]);*/
		if (isOpen(data[j])) {
			alert("jump!");			
			//getList(data[j],data[j].nameLong);		
		}
	}
		})
		.fail(function() {
			alert('Error: Unable access federation list');});
		})
function isOpen(w) {
jQuery.post(w.baseURL+'ajax_status.php', {}, function (data) {
if(data.status=='open') {
return true;
}
else {
return false;
}
})
.fail(function() {
			return false;
			});
		}
function getList(w, z) {
jQuery.post(w.baseURL+'ajax_listing.php', {}, function (data) {
var rt = "";
	var tab = document.getElementById('feds2');
	var i = tab.rows.length;
	var len = data.length;
for (j = len - 1; j >= 0; j--) {
	rt  = "<tr><td>";
		rt += z+"</td>";
		rt += "<td id = "+data[j].name+">" + data[j].name + "</td> </tr>";
		var rr = tab.insertRow(i);
		rr.innerHTML = rt;
		
}	
})
.fail(function() {
			return false;
			});
		}