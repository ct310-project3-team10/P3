<?php
$loginPage = FALSE;
include "page_init.php";
include_once "support.php";

$users = readUsers();
?>

<?php
if (isset ( $_POST ['password'] ) && isset($_POST['password2'])) {
	if ($_POST ['password'] == $_POST['password2']) {
		$newPass = password_hash($_POST['password'], PASSWORD_BCRYPT);
		foreach($users as $us) {
			if($us->user_name == $_SESSION['un']) {
				$us->hash = $newPass;
			}
		}
		writeUsers($users);
		header ( "Location: https://$host$uri/log_out.php" );
		exit ();
	} else {
		echo "Passwords must match";
	}
}
if (isset($_POST['username']) && isset($_POST['password'])) : ?>
 <p>Invalid username/password<br>
<?php echo date ( "l d, M. g:i a", time () )?></p>

<?php else : ?>
 <form align="center" action="" method="post">
 <p>New Password:  </p><input type="password" name="password"><br>
 <p>Confirm password:</p> <input type="password" name="password2"><br>
 <input type="submit">
 </form>
 <?php endif; ?>



<?php include "footer.php";?>