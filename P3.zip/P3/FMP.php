<?php
$loginPage = TRUE;
include "page_init.php";
include_once "support.php";

if(isset($_SESSION['key'])) {
	header ( "Location: https://$host$uri/password_reset.php" );
	exit ();
}

$users = readUsers();
?>
		
	<div class="contents">
			<p>Select your name and enter email:</p>
			<form action="./FMP.php" method="post" >
				<select name="username" style="color: black;">	
				<?php 
				echo "\n";
				foreach ($users as $u) {
	           $flag = ($u->user_name == $_SESSION['un']) ? 'selected' : '';
	           echo "\t\t\t\t<option value=\"$u->user_name\" $flag > $u->user_name </option>\n";
	         }
				?>
				</select> 
				<input type="email" name="email" style = "color: black;">
				<input type="submit" style = "color: black;" >
			</form>
		</div>
	<?php 
	if(isset($_POST['email']) && isset($_POST['username'])) {
		foreach($users as $u2) {
			if(($u2->email == $_POST['email']) && ($u2->user_name == $_POST['username'])) {
				$_SESSION['un'] = $u2->user_name;
				$str = $u2->email;
				$shuffled = str_shuffle($str);
				$_SESSION['key'] = $shuffled;
				$sent = "https://$host$uri/FMP.php?key=" . $shuffled;
			
				error_reporting(0);
				if(mail($str, 'Password Reset', $sent)) {
					echo "Confirmation sent to email";
				}
			}
		}
	}
	?>




<?php include "footer.php"; ?>