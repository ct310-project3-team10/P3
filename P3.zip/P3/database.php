<?php
require_once ("ingredient.php");
require_once ("comment.php");
class Database extends PDO{
	public function __construct() {
		parent::__construct( "sqlite: ingredients.db");}
	function getNumberOfIngredients($db) {
		$ing_num = $db->query ("SELECT count(*) FROM ingredient");
		return $ing_num->fetchColumn ();
	}
	function getNumberOfComments($db) {
		$ing_num = $db->query ("SELECT count(*) FROM Comments");
		return $ing_num->fetchColumn ();
	}
	function getPhoto() {
		$ing_photo = $this->query ("SELECT photo(*) FROM ingredient");
		return $ing_photo;
	}
	
	function getDetails($id,$db) {
		$sql = "SELECT name, description, photo, id, price
					FROM ingredient WHERE id = $id";
		$result = $db->query ( $sql );
		if ($result === FALSE) {
			// Only doing this for class. Would never do this in real life
			echo $sql;
			echo '<pre class="bg-danger">';
			print_r ( $db->errorInfo () );
			echo '</pre>';
			return NULL;
		}
		return ingredient::getIngredientFromRow ( $result->fetch () );
	}
	
	function getIngredients($db){
	$ingred=array();
	$c = database::getNumberOfIngredients($db);
	for($i=1;$i<=$c;$i++){
	$result=$db->query("SELECT name, id FROM ingredient WHERE id = $i");	
	$ingred[] = ingredient::getLI($result->fetch());}
	return $ingred;}
function getComments($a, $db){
	$ingred=array();
	$c = database::getNumberOfComments($db);
	for($i=1;$i<=$c;$i++){
	$result=$db->query("SELECT comment, id FROM Comments WHERE com_id = $i");
	//$z = comment::getLI($r->fetch);	
	$ingred[] = comment::getLI($result->fetch());
	}
	$return = array();
	foreach ($ingred as $i){
	if($i->id == $a) {
	array_push($return, $i);}}
	return $return;}

}