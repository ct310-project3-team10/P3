<?php
header ( "Access-Control-Allow-Origin: *" );
       $z='./pictures/'.$_GET['ing'].'.jpg';
       		$fp = fopen($z, 'rb');
       		$a = file_get_contents($z, FILE_USE_INCLUDE_PATH);
				$s = base64_encode($a);
echo $s;
?>
