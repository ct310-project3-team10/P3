<?php
include_once "ingredient.php";
include_once "comment.php";
function setupConnectionI() {
	try {
		$dbh = new PDO ( "sqlite:./ingredients.db" );
		/*echo '<pre class="bg-success">';
		echo 'Connection successful.';
		echo '</pre>';*/
		return $dbh;
	} catch ( PDOException $e ) {
		echo '<pre class="bg-danger">';
		echo 'Connection failed (Help!): ' . $e->getMessage ();
		echo '</pre>';
		return FALSE;
	}
}
function setupConnectionU() {
	try {
		$dbh = new PDO ( "sqlite:./users.db" );
		/*echo '<pre class="bg-success">';
		echo 'Connection successful.';
		echo '</pre>';*/
		return $dbh;
	} catch ( PDOException $e ) {
		echo '<pre class="bg-danger">';
		echo 'Connection failed (Help!): ' . $e->getMessage ();
		echo '</pre>';
		return FALSE;
	}
}
function dropTableByName($tname) {
	global $dbh;
	$sql = "DROP TABLE IF EXISTS $tname";
	$status = $dbh->exec ( $sql );
	if ($status === FALSE) {
		echo '<pre class="bg-danger">';
		print_r ( $dbh->errorInfo () );
		echo '</pre>';
	} /*else {
		echo '<pre class="bg-success">';
		echo 'Number of rows effected: ' . $status;
		echo '</pre>';
	}*/
}
function createTableIngredient($db) {
	$sql = "CREATE TABLE ingredient (
            name text, description varchar(300), photo text, id int, price int)";
	createTableGeneric ( $sql, $db );
}

function createTableComments($db) {
	$sql = "CREATE TABLE Comments (
			   comment varchar(300), 
			   id int,
			   com_id int)";
	createTableGeneric ( $sql, $db );
}

function createTableUsers($db) {
	$sql = "CREATE TABLE Users (
			   user_name text, 
			   email text,
			   hash varchar(30),
			   status text)";
	createTableGeneric ( $sql, $db );
}

function createTableGeneric($sql, $db) {
	//global $dbh;
	$status = $db->exec ( $sql );
	if ($status === FALSE) {
		echo '<pre class="bg-danger">';
		print_r ( $db->errorInfo () );
		echo '</pre>';
	} /*else {
		echo '<pre class="bg-success">';
		echo 'Number of rows effected: ' . $status;
		echo '</pre>';
	}*/
}
function loadEmptyDatabase($db) {
	//global $dbh;
	require "source_file/list.php";
	$ingredients = getFromFile ("/ingredients.csv");
	//$i_ids = array (); // Stores artists and SQL index
	
	$sql_ing = "INSERT INTO ingredient (name, description, photo, id, price)
									 VALUES (:name, :description, :photo, :id, :price)";
	// This allows caching of statements and optimized queries
	
	$ing_stm = $db->prepare ( $sql_ing );
	foreach ( $ingredients as $c_i ) {
		/*// 1. Check to make sure artist hasn't already been added
		if (key_exists ( $c_i ['name'], $i_ids )) {
			$i_id = $i_ids [$c_i ['name']];
		} else {
			$i_id = $dbh->lastInsertId ( 'id' );
			$i_ids [$c_i ['name']] = $i_id;
		}*/
		testedInsertIngredient ( $c_i, $ing_stm, $db );
	}
}
function loadEmptyDatabaseU($db) {
	//global $dbh;
	require "source_file/list.php";
	$users = getFromFile ("users.csv");
	//$i_ids = array (); // Stores artists and SQL index
	
	$sql_ing = "INSERT INTO Users (user_name, email, hash, status) VALUES (:user_name, :email, :hash, :status)";
	// This allows caching of statements and optimized queries
	
	$ing_stm = $db->prepare ( $sql_ing );
	foreach ( $users as $c_i ) {
		/*// 1. Check to make sure artist hasn't already been added
		if (key_exists ( $c_i ['name'], $i_ids )) {
			$i_id = $i_ids [$c_i ['name']];
		} else {
			$i_id = $dbh->lastInsertId ( 'id' );
			$i_ids [$c_i ['name']] = $i_id;
		}*/
		testedInsertUser ( $c_i, $ing_stm, $db );
	}
}
function testedInsertComment($name, $db) {
	//global $dbh;
	$sql_com = "INSERT INTO Comments (comment, id, com_id) VALUES (:comment, :id, :com_id)";
	$com_stm = $db->prepare ( $sql_com );	
	if (! $com_stm->execute ( array(':comment'=>$name['comment'],
										':id'=>$name['id'],
										':com_id'=>$name['com_id']))) {
		echo '<pre class="bg-danger">';
		print_r ( $db->errorInfo () );
		echo '</pre>';
	}
}
function InsertUser($name, $db) {
	//global $dbh;
	$sql_com = "INSERT INTO Users (user_name, email, hash, status) VALUES (:user_name, :email, :hash, :status)";
	$com_stm = $db->prepare ( $sql_com );	
	if (! $com_stm->execute ( array(':user_name'=>$name['user_name'],
										':email'=>$name['email'],
										':hash'=>$name['hash'],
										':status'=>$name['status']))) {
		echo '<pre class="bg-danger">';
		print_r ( $db->errorInfo () );
		echo '</pre>';
	}
}
function InsertIngredient($ingredient, $db) {
	//global $dbh;
	$sql_ing = "INSERT INTO ingredient (name, description, photo, id, price)
									 VALUES (:name, :description, :photo, :id, :price)";
	$ing_stm = $db->prepare ( $sql_ing );	
	if (! $ing_stm->execute ( array (
			':name' => $ingredient ['name'],
			':description' => $ingredient ['description'],
			':photo' => $ingredient ['photo'],
			':id' => $ingredient ['id'],
			':price' => $ingredient['price']))) {
		echo '<pre class="bg-danger">';
		print_r ( $db->errorInfo () );
		echo '</pre>';
	}
}
function testedInsertUser($user, $stmt, $db) {
	//global $dbh;
	if (! $stmt->execute ( array(':user_name'=>$name['user_name'],
										':email'=>$name['email'],
										':hash'=>$name['hash'],
										':status'=>$name['status']))) {
		echo '<pre class="bg-danger">';
		print_r ( $db->errorInfo () );
		echo '</pre>';
	}
}
function testedInsertIngredient($ingredient, $stmt, $db) {
	//global $dbh;
	if (! $stmt->execute ( array (
			':name' => $ingredient ['name'],
			':description' => $ingredient ['description'],
			':photo' => $ingredient ['photo'],
			':id' => $ingredient ['id'],
			':price' => $ingredient['price'] 
	) )) {
		echo '<pre class="bg-danger">';
		print_r ( $db->errorInfo () );
		echo '</pre>';
	}
}

?>