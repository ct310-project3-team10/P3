<?php
$ses_name = "log_on";
session_name($ses_name);
session_start();
session_unset();
session_destroy();
header("Location: http://www.cs.colostate.edu/~mlwells/P2/login.php");
?>