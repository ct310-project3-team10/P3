<?php
require_once "assets/passwordLib.php";
class User {
	public $user_name = ''; /* UserName */
	public $email = ''; /* Users Email */
	public $hash = ''; /* Hash of password */
	public $status = '';
}
function makeNewUser($um, $em, $h, $s) {
	$u = new User ();
	$u->user_name = $um;
	$u->email = $em;
	$u->hash = $h;
	$u->status = $s;
	return $u;
}
function setupDefaultUsers() {
	$users = array ();
	$i = 0;
	$users [$i ++] = makeNewUser ( 'mlwells', 'cdmi2@comcast.net', '$2a$10$rpaYL2pJTdO6x1VZoB59TOrngHTBFceYXXmxyNH6fxWJwtoJjuwbC', 'admin' );
	$users [$i ++] = makeNewUser ( 'ct310', 'ct310@cs.colostate.edu', '$2a$10$AoWRyJ/EvpnVfchrezeTKuzJBYBomjiG3AszuFw2mvWAvJf2APojO', 'admin');
	$users [$i ++] = makeNewUser ( 'mlwells1', 'cdmi2@comcast.net', '$2a$10$rpaYL2pJTdO6x1VZoB59TOrngHTBFceYXXmxyNH6fxWJwtoJjuwbC', 'user' );
	$users [$i ++] = makeNewUser ( 'fred', 'ct310@cs.colostate.edu', '$2a$10$s./cnExseYxXIemZCSFiS.XG.sXI02UVjjiKto10jYxrKq7d6UCsO', 'user');
	$users [$i ++] = makeNewUser ( 'ndbart', 'ndbarteaux@gmail.com', '$2a$10$r4SPwnNXlj5vVjYyCbTrGOz5FkJwPz21csdaEau8zngvlHxbQl3hi', 'admin');
	$_SESSION['nou']=$i;
	echo $_SESSION['nou'];
	writeUsers ( $users );
	
}
function writeUsers($users) {
	$fh = fopen ( './source_file/users.csv', 'w+' ) or die ( "Can't open file" );
	fputcsv ( $fh, array_keys ( get_object_vars ( $users [0] ) ) );
	for($i = 0; $i < count ( $users ); $i ++) {
		fputcsv ( $fh, get_object_vars ( $users [$i] ) );
	}
	fclose ( $fh );
}

function readUsers() {
	if (! file_exists ( './source_file/users.csv' )) {
		setupDefaultUsers ();
	}
	$users = array ();
	$fh = fopen ( './source_file/users.csv', 'r' ) or die ( "Can't open file" );
	$keys = fgetcsv ( $fh );
	$_SESSION['nou']=0;
	
	while ( ($vals = fgetcsv ( $fh )) != FALSE ) {
		$_SESSION['nou']++;
		if (count ( $vals ) > 1) {
			$u = new User ();
			for($k = 0; $k < count ( $vals ); $k ++) {
				$u->$keys [$k] = $vals [$k];
			}
			$users [] = $u;
		}
	}
	fclose ( $fh );
	return $users;
}
function userHashByName($users, $full_name) {
	$res = '';
	foreach ( $users as $u ) {
		if ($u->user_name == $full_name) {
			$res = $u->hash;
		}
	}
	return $res;
}

?>