<?php 
$loginPage = TRUE;
include "page_init.php";
?>
<script type="text/javascript" src="fedr_status.js">
</script>
		<div class="container-fluid">
			<div class="row visible-on">
			<h3>Below is a list of member sites. This federation of companies allows us to supply you with a larger variety of ingredients sourced from diverse locations.</h3>
			<h3>If a company is green then they are currently accepting orders. If they are red then they are not currently accepting orders. If they are yellow then their website is not responding.</h3>
				<table id="feds">
			<tr>
				<th>ShortName</th>
				<th>Name</th>
			</tr>
		</table>
			</div>
		</div>
		
	</body>
	<div id="footer">
		<?php include "footer.php"; ?>
	</div>
</html>